<?php
/**
 * Plugin Name: VeriFactu Express for WooCommerce
 * Plugin URI: https://verifactu-express.com
 * Description: Adaptación oficial de WooCommerce a la normativa VeriFactu (RD 1007/2023 y Orden HAC/1177/2024). Genera la huella canónica SHA-256 encadenada y el código QR oficial de la Agencia Tributaria (AEAT) en cada pedido.
 * Version: 1.0.0
 * Author: Open Compliance Project
 * Author URI: https://verifactu-express.com
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: verifactu-express
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * WC requires at least: 5.0
 * WC tested up to: 9.3
 */

if (!defined('ABSPATH')) {
    exit; // Seguridad: Salir si se accede directamente
}

/**
 * Clase Principal del Plugin VeriFactu Express
 */
class VeriFactu_Express {

    const VERSION = '1.0.0';

    public function __construct() {
        // Registrar menú de administración en WordPress
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));

        // Declarar compatibilidad con WooCommerce HPOS (High-Performance Order Storage)
        add_action('before_woocommerce_init', array($this, 'declare_hpos_compatibility'));

        // Disparador al completar un pedido en WooCommerce
        add_action('woocommerce_order_status_completed', array($this, 'process_order_verifactu'), 10, 1);

        // Mostrar información de verificación en el panel de pedido del administrador
        add_action('add_meta_boxes', array($this, 'add_order_meta_box'));

        // Mostrar el QR de la AEAT en la página de agradecimiento del cliente
        add_action('woocommerce_thankyou', array($this, 'display_customer_verification'), 20, 1);
    }

    /**
     * Declara compatibilidad con HPOS en WooCommerce moderno.
     */
    public function declare_hpos_compatibility() {
        if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
            \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
        }
    }

    /**
     * Añade la página de ajustes en el menú de WordPress.
     */
    public function add_admin_menu() {
        add_submenu_page(
            'woocommerce',
            __('Ajustes VeriFactu', 'verifactu-express'),
            __('🛡️ VeriFactu AEAT', 'verifactu-express'),
            'manage_woocommerce',
            'verifactu-settings',
            array($this, 'render_settings_page')
        );
    }

    /**
     * Registra las opciones de configuración en la base de datos de WordPress.
     */
    public function register_settings() {
        register_setting('verifactu_options_group', 'verifactu_nif_emisor', array(
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default'           => ''
        ));

        register_setting('verifactu_options_group', 'verifactu_serie_prefijo', array(
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default'           => 'F2026-'
        ));

        register_setting('verifactu_options_group', 'verifactu_modo_registro', array(
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default'           => 'F1'
        ));
    }

    /**
     * Renderiza la interfaz de ajustes en el panel de administración.
     */
    public function render_settings_page() {
        if (!current_user_can('manage_woocommerce')) {
            return;
        }

        $last_hash = get_option('verifactu_last_hash', '');
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('Configuración VeriFactu (Agencia Tributaria - RD 1007/2023)', 'verifactu-express'); ?></h1>
            <p><?php esc_html_e('Este plugin calcula automáticamente la huella SHA-256 encadenada canónica y genera la URL oficial del código QR de la AEAT según las especificaciones de la Orden HAC/1177/2024.', 'verifactu-express'); ?></p>

            <form method="post" action="options.php" style="background:#fff; padding:20px; border:1px solid #ccd0d4; border-radius:8px; max-width:700px;">
                <?php settings_fields('verifactu_options_group'); ?>
                <?php do_settings_sections('verifactu_options_group'); ?>

                <table class="form-table">
                    <tr valign="top">
                        <th scope="row"><?php esc_html_e('NIF / CIF del Emisor', 'verifactu-express'); ?></th>
                        <td>
                            <input type="text" name="verifactu_nif_emisor" value="<?php echo esc_attr(get_option('verifactu_nif_emisor')); ?>" class="regular-text" placeholder="B12345674" required />
                            <p class="description"><?php esc_html_e('NIF fiscal de la empresa o autónomo titular de la tienda.', 'verifactu-express'); ?></p>
                        </td>
                    </tr>

                    <tr valign="top">
                        <th scope="row"><?php esc_html_e('Prefijo de Serie de Facturación', 'verifactu-express'); ?></th>
                        <td>
                            <input type="text" name="verifactu_serie_prefijo" value="<?php echo esc_attr(get_option('verifactu_serie_prefijo', 'F2026-')); ?>" class="regular-text" />
                            <p class="description"><?php esc_html_e('Prefijo para la numeración de factura (ejemplo: F2026-).', 'verifactu-express'); ?></p>
                        </td>
                    </tr>

                    <tr valign="top">
                        <th scope="row"><?php esc_html_e('Tipo de Factura por Defecto', 'verifactu-express'); ?></th>
                        <td>
                            <select name="verifactu_modo_registro">
                                <option value="F1" <?php selected(get_option('verifactu_modo_registro'), 'F1'); ?>><?php esc_html_e('F1 - Factura Completa Ordinaria', 'verifactu-express'); ?></option>
                                <option value="F2" <?php selected(get_option('verifactu_modo_registro'), 'F2'); ?>><?php esc_html_e('F2 - Factura Simplificada (Ticket)', 'verifactu-express'); ?></option>
                            </select>
                        </td>
                    </tr>
                </table>

                <?php submit_button(__('Guardar Configuración VeriFactu', 'verifactu-express')); ?>
            </form>

            <div style="margin-top:20px; background:#fff; padding:15px; border:1px solid #ccd0d4; border-radius:8px; max-width:700px;">
                <h3><?php esc_html_e('Estado del Encadenamiento Criptográfico', 'verifactu-express'); ?></h3>
                <p><strong><?php esc_html_e('Última Huella SHA-256 Registrada:', 'verifactu-express'); ?></strong></p>
                <code style="display:block; padding:10px; background:#f0f0f1; word-break:break-all;">
                    <?php echo $last_hash ? esc_html($last_hash) : esc_html__('Sin registros previos (El primer pedido generado iniciará la cadena con huella vacía según la norma AEAT).', 'verifactu-express'); ?>
                </code>
            </div>
        </div>
        <?php
    }

    /**
     * Calcula la huella canónica SHA-256 bajo la Orden HAC/1177/2024 y AEAT v0.1.2.
     */
    public function compute_aeat_hash($nif, $num_serie, $fecha_exp, $tipo, $cuota, $total, $huella_anterior, $timestamp_iso) {
        // Formato canónico estricto: IDEmisorFactura=...&NumSerieFactura=...
        $canonical_string = sprintf(
            'IDEmisorFactura=%s&NumSerieFactura=%s&FechaExpedicionFactura=%s&TipoFactura=%s&CuotaTotal=%.2f&ImporteTotal=%.2f&Huella=%s&FechaHoraHusoGenRegistro=%s',
            trim($nif),
            trim($num_serie),
            trim($fecha_exp),
            trim($tipo),
            floatval($cuota),
            floatval($total),
            trim($huella_anterior),
            trim($timestamp_iso)
        );

        $hash = strtoupper(hash('sha256', $canonical_string));

        return array(
            'canonical_string' => $canonical_string,
            'hash'             => $hash
        );
    }

    /**
     * Genera la URL oficial del código QR de cotejo en la Sede Electrónica de la AEAT.
     */
    public function generate_qr_url($nif, $num_serie, $fecha_exp, $total, $hash) {
        $base_url = 'https://sede.agenciatributaria.gob.es/Sede/verifactu/consulta';
        $params = array(
            'nif'   => trim($nif),
            'num'   => trim($num_serie),
            'fecha' => trim($fecha_exp),
            'total' => number_format(floatval($total), 2, '.', ''),
            'hash'  => substr($hash, 0, 16)
        );

        return $base_url . '?' . http_build_query($params);
    }

    /**
     * Procesa un pedido cuando pasa a estado 'completed'.
     */
    public function process_order_verifactu($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }

        // Evitar procesar dos veces el mismo pedido
        if ($order->get_meta('_verifactu_hash')) {
            return;
        }

        $nif_emisor = get_option('verifactu_nif_emisor', '');
        if (empty($nif_emisor)) {
            return; // No configurado
        }

        $prefijo    = get_option('verifactu_serie_prefijo', 'F2026-');
        $tipo       = get_option('verifactu_modo_registro', 'F1');
        $num_serie  = $prefijo . str_pad($order_id, 6, '0', STR_PAD_LEFT);
        
        $fecha_exp  = $order->get_date_created() ? $order->get_date_created()->date('d-m-Y') : date('d-m-Y');
        $total      = $order->get_total();
        $cuota_iva  = $order->get_total_tax();

        // Obtener última huella del encadenamiento
        $prev_hash  = get_option('verifactu_last_hash', '');

        // Formato ISO 8601 con huso horario oficial (+01:00 o +02:00)
        $timestamp_iso = date('Y-m-d\TH:i:sP');

        // Cálculo determinista
        $result = $this->compute_aeat_hash($nif_emisor, $num_serie, $fecha_exp, $tipo, $cuota_iva, $total, $prev_hash, $timestamp_iso);
        $qr_url = $this->generate_qr_url($nif_emisor, $num_serie, $fecha_exp, $total, $result['hash']);

        // Guardar metadatos en el pedido
        $order->update_meta_data('_verifactu_num_serie', $num_serie);
        $order->update_meta_data('_verifactu_hash', $result['hash']);
        $order->update_meta_data('_verifactu_qr_url', $qr_url);
        $order->update_meta_data('_verifactu_canonical', $result['canonical_string']);
        $order->save();

        // Actualizar el estado del encadenamiento en la base de datos
        update_option('verifactu_last_hash', $result['hash']);
    }

    /**
     * Añade una caja de metadatos en la vista de edición del pedido en wp-admin.
     */
    public function add_order_meta_box() {
        $screen = class_exists('\Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController') &&
                  wc_get_container()->get(\Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController::class)->custom_orders_table_usage_is_enabled()
                  ? wc_get_page_screen_id('shop_order')
                  : 'shop_order';

        add_meta_box(
            'verifactu_order_box',
            __('🛡️ Datos de Registro VeriFactu (AEAT)', 'verifactu-express'),
            array($this, 'render_order_meta_box'),
            $screen,
            'side',
            'default'
        );
    }

    public function render_order_meta_box($post_or_order) {
        $order = is_a($post_or_order, 'WC_Order') ? $post_or_order : wc_get_order($post_or_order->ID);
        if (!$order) return;

        $hash   = $order->get_meta('_verifactu_hash');
        $num    = $order->get_meta('_verifactu_num_serie');
        $qr_url = $order->get_meta('_verifactu_qr_url');

        if ($hash) {
            echo '<p><strong>' . esc_html__('Serie/Factura:', 'verifactu-express') . '</strong> <code>' . esc_html($num) . '</code></p>';
            echo '<p><strong>' . esc_html__('Huella SHA-256:', 'verifactu-express') . '</strong><br><code style="font-size:10px; word-break:break-all;">' . esc_html($hash) . '</code></p>';
            echo '<p><a href="' . esc_url($qr_url) . '" class="button button-small" target="_blank" rel="noopener">' . esc_html__('Verificar en Sede AEAT &rarr;', 'verifactu-express') . '</a></p>';
        } else {
            echo '<p style="color:#666;"><em>' . esc_html__('Este pedido aún no ha sido completado ni registrado en VeriFactu.', 'verifactu-express') . '</em></p>';
        }
    }

    /**
     * Muestra la verificación oficial en la pantalla de confirmación del cliente.
     */
    public function display_customer_verification($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) return;

        $hash   = $order->get_meta('_verifactu_hash');
        $qr_url = $order->get_meta('_verifactu_qr_url');

        if ($hash && $qr_url) {
            echo '<div style="margin: 25px 0; padding: 16px; border: 1px solid #e2e8f0; border-radius: 8px; background: #f8fafc;">';
            echo '<h4 style="margin: 0 0 8px 0; color: #0f172a;">🛡️ Factura Verificada ante la Agencia Tributaria (VeriFactu)</h4>';
            echo '<p style="font-size: 13px; color: #475569; margin-bottom: 8px;">Esta compra genera un registro tributario inalterable conforme al RD 1007/2023 y la Orden HAC/1177/2024.</p>';
            echo '<p style="font-size: 11px; font-family: monospace; color: #64748b; margin-bottom: 12px; word-break: break-all;">Huella SHA-256: ' . esc_html($hash) . '</p>';
            echo '<a href="' . esc_url($qr_url) . '" target="_blank" rel="noopener" style="display: inline-block; padding: 8px 14px; background: #0284c7; color: #fff; text-decoration: none; border-radius: 6px; font-size: 13px; font-weight: 600;">Cotejar Factura en la Sede Electrónica de la AEAT &rarr;</a>';
            echo '</div>';
        }
    }
}

// Inicializar el plugin
new VeriFactu_Express();
