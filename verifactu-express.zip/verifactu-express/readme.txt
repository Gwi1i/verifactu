=== VeriFactu Express for WooCommerce ===
Contributors: opencompliance
Donate link: https://verifactu-express.com
Tags: verifactu, aeat, factura electronica, woocommerce, hacienda, factura, ticketbai
Requires at least: 5.8
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Adaptación oficial y autónoma de WooCommerce a la normativa VeriFactu (RD 1007/2023 y Orden HAC/1177/2024).

== Description ==

**VeriFactu Express for WooCommerce** es la solución ligera, autónoma y sin cuotas mensuales para adaptar tu tienda online WooCommerce a las exigencias del **Real Decreto 1007/2023 (Ley Antifraude)** y la **Orden Ministerial HAC/1177/2024**.

El plugin opera de forma 100% local en tu propio servidor WordPress, garantizando la máxima privacidad y rendimiento sin necesidad de enviar los datos de tus clientes a plataformas intermediarias externas.

### Características Principales:
* **Cálculo Canónico de Huella SHA-256:** Implementa el algoritmo oficial y el orden canónico estricto de campos fijado en la Orden HAC/1177/2024 y la especificación técnica v0.1.2 de la AEAT.
* **Encadenamiento Criptográfico Automático:** Cada pedido completado incluye la huella del registro anterior, asegurando la inalterabilidad de la serie de facturación.
* **Generación de URL y Código QR Oficial:** Construye automáticamente la URL y el código QR de verificación para el cotejo directo en la Sede Electrónica de la Agencia Tributaria.
* **Compatible con HPOS (High-Performance Order Storage):** Diseñado con compatibilidad nativa para las tablas de pedidos personalizadas de WooCommerce moderno.
* **Privacidad y Soberanía de Datos:** No requiere API keys de terceros, no cobra comisiones por factura y no almacena tus datos fiscales fuera de tu propia base de datos de WordPress.
* **Integración en Panel de Administración:** Añade una caja de metadatos en cada pedido con la serie, la huella SHA-256 y el botón de verificación directa en Hacienda.

== Installation ==

1. Sube la carpeta `verifactu-express` al directorio `/wp-content/plugins/` de tu servidor o sube el archivo `.zip` desde **Plugins > Añadir nuevo > Subir plugin**.
2. Activa el plugin a través del menú **Plugins** en WordPress.
3. Ve a **WooCommerce > 🛡️ VeriFactu AEAT** en tu panel de administración.
4. Introduce tu NIF/CIF emisor, tu prefijo de facturación (ej: `F2026-`) y guarda los cambios.
5. ¡Listo! A partir de ese momento, cada pedido completado generará automáticamente su huella encadenada y su QR de cotejo reglamentario.

== Frequently Asked Questions ==

= ¿Cumple este plugin con la Orden HAC/1177/2024? =
Sí. El plugin ha sido verificado contra los vectores de prueba oficiales publicados por la Agencia Tributaria en el documento técnico v0.1.2, cumpliendo bit a bit con la concatenación de los 8 campos oficiales y el algoritmo SHA-256.

= ¿Necesito certificados digitales o firma externa para usar este plugin? =
En la modalidad estándar de generación de registros VeriFactu con código QR para verificación por parte del cliente en la sede electrónica de la AEAT, no requiere firma delegada en servidores externos.

= ¿Es compatible con plugins de facturación en PDF? =
Sí. El plugin guarda los metadatos `_verifactu_hash` y `_verifactu_qr_url` en los campos personalizados del pedido, lo que permite mostrarlos fácilmente en plantillas de plugins como WooCommerce PDF Invoices & Packing Slips.

== Screenshots ==

1. Panel de configuración en WooCommerce > VeriFactu AEAT.
2. Caja de información técnica VeriFactu en la vista de edición del pedido.
3. Aviso de verificación tributaria con enlace a la AEAT en la pantalla de pedido completado.

== Changelog ==

= 1.0.0 =
* Versión inicial de lanzamiento.
* Cálculo canónico SHA-256 según Orden HAC/1177/2024.
* Generación de URL QR para la Sede Electrónica de la AEAT.
* Soporte nativo para WooCommerce HPOS.
